% Global sensitivity and uncertainty analysis using GSUA Toolbox
% https://bit.ly/Matlab_GSUA
% (c) Carlos Mario Vélez S. 2022
% Universidad EAFIT, Medellin, Antioquia, Colombia
% https://sis-control.blogspot.com/

% Model description:                            S.description('text...');
% Factor names:                                 S.factor_names = {'text1','text2',..};
% Nominal factors and respective uncertainties: S.x = [v1 v2,...,vn; u1 u2 ... un];
% Simulation model:                             S.model = 'text...';

S.description = 'Modelo de Infección del VIH-1';
S.factor_names = {'s','d','B','mu','c','k'};
S.x = [10 0.02 2.4*10^-5 0.24 2.4 100; 25 25 25 25 25 25]; 
S.model = 'Modelo_Infeccion_VIH_Controlador_Continuo_RuidoA1';